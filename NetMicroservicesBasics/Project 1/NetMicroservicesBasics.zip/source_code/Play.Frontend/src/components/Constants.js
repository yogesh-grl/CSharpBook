export const ApplicationPaths = {
  CatalogPath: '/catalog',
  InventoryPath: '/inventory'
};
