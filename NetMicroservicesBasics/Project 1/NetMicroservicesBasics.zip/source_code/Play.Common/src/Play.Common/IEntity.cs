using System;

namespace Play.Common
{
    public interface IEntity
    {
        Guid Id { get; set; }
    }
}